var searchData=
[
  ['ilocalaudiodatalistener',['ILocalAudioDataListener',['../interfacecom_1_1hyphenate_1_1chat_1_1_e_m_conference_manager_1_1_i_local_audio_data_listener.html',1,'com::hyphenate::chat::EMConferenceManager']]],
  ['iremoteaudiodatalistener',['IRemoteAudioDataListener',['../interfacecom_1_1hyphenate_1_1chat_1_1_e_m_conference_manager_1_1_i_remote_audio_data_listener.html',1,'com::hyphenate::chat::EMConferenceManager']]]
];
