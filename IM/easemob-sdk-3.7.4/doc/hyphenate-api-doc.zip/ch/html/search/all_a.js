var searchData=
[
  ['kickalldevices',['kickAllDevices',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_client.html#a3251f572e2d5cc61ce25b8a9dbb2d824',1,'com::hyphenate::chat::EMClient']]],
  ['kickdevice',['kickDevice',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_client.html#ab358581a157c9eaf8a7c37cf54d42576',1,'com::hyphenate::chat::EMClient']]],
  ['kickmember',['kickMember',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_conference_manager.html#af8762ac9fa0fd293f05b4bcf1efbef10',1,'com::hyphenate::chat::EMConferenceManager']]]
];
