var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvå",
  1: "acdeilmst",
  2: "abcdefghijklmoprstu",
  3: "acdefgimnprsuv",
  4: "v",
  5: "å"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enumvalues",
  5: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "函数",
  3: "变量",
  4: "枚举值",
  5: "页"
};

