var searchData=
[
  ['handleadminapplication',['handleAdminApplication',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_conference_manager.html#a7bfb8311b9fa7e43b85d8940bb6850f9',1,'com::hyphenate::chat::EMConferenceManager']]],
  ['handlespeakerapplication',['handleSpeakerApplication',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_conference_manager.html#affaa83f9c32e5a99caa7ec0627ddfcb2',1,'com::hyphenate::chat::EMConferenceManager']]]
];
