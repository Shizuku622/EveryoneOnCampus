var searchData=
[
  ['localbinder',['LocalBinder',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_service_1_1_local_binder.html',1,'com::hyphenate::chat::EMChatService']]]
];
